
const scrollRevealOption = {
  distance: "50px",
  origin: "top",
  duration: 750,
};

ScrollReveal().reveal(".Hero-Photo img", {
  ...scrollRevealOption,
  origin: "right",
});
ScrollReveal().reveal(".Hero-Text h2", {
  ...scrollRevealOption,
  delay: 500,
});
ScrollReveal().reveal(".Hero-Text p", {
  ...scrollRevealOption,
  delay: 500,
});
ScrollReveal().reveal(".productswrapper h2", {
  ...scrollRevealOption,
  delay: 750,
});
ScrollReveal().reveal(".Top-Products ", {
  ...scrollRevealOption,
  delay: 750,
});
ScrollReveal().reveal(".footbars", {
  ...scrollRevealOption,
  delay: 750,
});
ScrollReveal().reveal(".col1", {
    ...scrollRevealOption,
    delay: 750,
    origin: "left",
  });
  ScrollReveal().reveal(".col5", {
    ...scrollRevealOption,
    delay: 750,
  });

  ScrollReveal().reveal(".col3", {
    ...scrollRevealOption,
    origin: "right",
    delay: 750,
  });

  

  ScrollReveal().reveal(".Hero-Photo2 img", {
    ...scrollRevealOption,
    origin: "right",
  });
  ScrollReveal().reveal(".Hero-Text2 h2", {
    ...scrollRevealOption,
    delay: 500,
  });
  ScrollReveal().reveal(".Hero-Text2 p", {
    ...scrollRevealOption,
    delay: 500,
  });
  ScrollReveal().reveal(".Hero-Buttons", {
    ...scrollRevealOption,
    delay: 750,
  });
  ScrollReveal().reveal(".review", {
    ...scrollRevealOption,
    delay: 750,
    origin: "bottom",
  });
  ScrollReveal().reveal(".products", {
    ...scrollRevealOption,
    delay: 750,
  });
  ScrollReveal().reveal(".col1", {
      ...scrollRevealOption,
      delay: 750,
      origin: "left",
    });
    ScrollReveal().reveal(".col5", {
      ...scrollRevealOption,
      delay: 750,
    });
  
    ScrollReveal().reveal(".col3", {
      ...scrollRevealOption,
      origin: "right",
      delay: 750,
    });
 
  
  document.getElementById("Learn_More").addEventListener("click", function(){
    document.querySelector(".popup").style.display = "flex";
  })

document.querySelector("#close").addEventListener("click", function(){
  document.querySelector(".popup").style.display = "none";
})
